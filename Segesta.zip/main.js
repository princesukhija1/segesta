
function opn(x){
    document.getElementById("nav-bar").style.height="100vh";
    x.classList.toggle("change");
    document.getElementById("nav-bar").style.top="0px";
    document.getElementById("top").style.display="none"; 
    
}
function cls(){
    document.getElementById("nav-bar").style.height="0%";
    document.getElementById("nav-bar").style.top="-4px";
    document.getElementById("top").style.display="block";}
    
function tanet(){
document.getElementById("fst1").style.display="block";
    document.getElementById("fst2").style.display="block";
    document.getElementById("fst3").style.display="block";
}